This directory contains placeholder CHLOM artifacts. Replace these with the full Foundry scaffold, ZK circuit skeletons, gas reports, calibration scripts, and other artifacts as needed.
